GeoServer Extension
===================

This extension adds a new functionality to GeoServer.

* https://docs.geoserver.org/latest/en/user/extensions/
* [LICENSE](LICENSE.md)

Installation
------------

1. Unzip this archive into the GeoServer library directory. In the binary
   install this is under ``<GEOSERVER_ROOT>/webapps/geoserver/WEB-INF/lib``.

2. Restart GeoServer.
